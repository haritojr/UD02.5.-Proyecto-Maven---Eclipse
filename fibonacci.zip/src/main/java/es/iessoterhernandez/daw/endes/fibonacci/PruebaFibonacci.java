package es.iessoterhernandez.daw.endes.fibonacci;

public class PruebaFibonacci {
	public static void main(String[] args) {
		
	}

}
