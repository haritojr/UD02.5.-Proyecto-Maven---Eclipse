package es.iessoterhernandez.daw.endes.fibonacciMain;

import es.iessoterhernandez.daw.endes.fibonacci.App;
public class App 
{
    public static void main( String[] args )
    {
    	App.fib(4);
    }
}
